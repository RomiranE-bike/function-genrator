/*
 * song.h
 *
 * Created: 11/20/2024 22:53:57
 *  Author: User
 */ 

#ifndef SONG_H_
#define SONG_H_
//---------------------------------------------------------------------------------------
#include <avr/io.h>
#include <util/delay.h>
//---------------------------------------------------------------------------------------
// The Frequency
#define C6  661
#define D6  588
#define E6  524
#define F6  495
#define G6  441
#define A6  393
#define B6  350
#define C7  330
#define PAUSE 80
//----------------------------------------------------------------------------------------
void play_note(unsigned int note,unsigned int duration)
{
	// Reset the 8 bit Counter
	TCNT0 = 0;
	TCNT1 = 0;

	// Set the Counter TOP
	OCR1C = ( note >> 8 ) & 0x00FF;
	OCR1A = note;
	// Turn on the Prescaler
	TCCR1B |= (1<<CS11);
	delay(duration);

	// Turn off the Prescaler
	TCCR1B &= ~(1<<CS11);
	_delay_ms(PAUSE);
}
//----------------------------------------------------------------------------------------
void delay(unsigned int delay){//about 0.5s if delay=30 500ms
	uint8_t i;
	uint8_t j;
	
		for(i=0;i<delay;i++){
			for(j=0;j<250;j++){
			   }
		}
}
//----------------------------------------------------------------------------------------
void play_song(void){
		play_note(C6,200);//Twin
		play_note(C6,200);//KLE
		play_note(G6,200);//Twin
		play_note(G6,200);//KLE
		play_note(A6,200);//Lit
		play_note(A6,200);//TLE
		play_note(G6,500);//Star
		play_note(F6,200);//How
		play_note(F6,200);//I
		play_note(E6,200);//Won
		play_note(E6,200);//DER
		play_note(D6,200);//What
		play_note(D6,200);//You
		//if(!repeat)
		play_note(C6,500);//" Are!"
		//else
		play_note(C6,1000);//" Are!"
		//if (!repeat)
		play_note(G6,200);//Up
		play_note(G6,200);//A
		play_note(F6,200);//BOVE
		play_note(F6,200);//The
		play_note(E6,200);//World
		play_note(E6,200);//So
		play_note(D6,500);//High
		play_note(G6,200);//Like
		play_note(G6,200);//A
		play_note(F6,200);//DIA
		play_note(F6,200);//MOND
		play_note(E6,200);//In
		play_note(E6,200);//The
		play_note(D6,500);//Sky
}
//---------------------------------------------------------------------------------------

#endif /* SONG_H_ */
//---------------------------------------------------------------------------------------