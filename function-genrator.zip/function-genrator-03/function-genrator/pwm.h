	/*
 * pwm.h
 *
 * Created: 11/20/2024 23:21:30
 *  Author: User
 */ 
//----------------------------------------------------------------------------------------------------------------
#ifndef PWM_H_
#define PWM_H_
//----------------------------------------------------------------------------------------------------------------
#include <avr/io.h>
#include <util/delay.h>
#include <avr/eeprom.h>
#include "io.h"
//----------------------------------------------------------------------------------------------------------------
#define	N_1	                    (1<<CS10)//(00000001) (Clock source) (1<<CS10)
#define	N_2	                    (1<<CS11)//(00000010) (Clock source/2) (1<<CS11)
#define	N_4	                    (1<<CS11)|(1<<CS10)//(00000011) (Clock source/4) (1<<CS11)|(1<<CS10)
#define	N_8	                    (1<<CS12)//(00000100) (Clock source/8) (1<<CS12)
#define	N_16                    (1<<CS12)|(1<<CS10)//(00000101) (Clock source/16) (1<<CS12)|(1<<CS10)
#define	N_32	                (1<<CS12)|(1<<CS11)//(00000110) (Clock source/32) (1<<CS12)|(1<<CS11)
#define	N_64	                (1<<CS12)|(1<<CS11)|(1<<CS10)//(00000111) (Clock source/64) (1<<CS12)|(1<<CS11)|(1<<CS10)
#define	N_128	                (1<<CS13)
#define	N_256	                (1<<CS13)|(1<<CS10)
#define	N_512	                (1<<CS13)|(1<<CS11)
#define	N_1024	                (1<<CS13)|(1<<CS11)|(1<<CS10)
#define F_CPU                   4000000              
//----------------------------------------------------------------------------------------------------------------
#define	f_1k	                    1000
#define	f_5k	                    5000
#define	f_10k                       10000
#define	f_H_line                    15625
#define	f_22k                       22000
#define	f_25k                       25000
#define	f_38k	                    38000
#define	f_44k	                    44000
#define	f_52k	                    52000
#define	f_60k	                    60000
#define	f_72k	                    72000
//----------------------------------------------------------------------------------------------------------------
unsigned char TOP_count_value; 
unsigned char duty_cycle;
unsigned char prescaler;
unsigned char top_value;
//----------------------------------------------------------------------------------------------------------------
void prescaler_change(void){
				/***********************************/
				uint8_t EE_value_1;
				EE_value_1 = eeprom_read_byte((uint8_t*)20); //read the value stored in the memory
				_delay_ms(20);
				switch (EE_value_1){
					case (1):
					prescaler =  N_16; 	                //f_cpu/16
					break;
					case (2):
					prescaler =  N_8; 	                //f_cpu/8
					break;
					case (3):
					prescaler =  N_2; 	                //f_cpu/2 =4Mhz
					break;
					case (4):
					prescaler =  N_1;	                //f_cpu/1 =8Mhz
					break;
					//default:
					//TCCR1B =  N_16;
				}//end of switch
				/*******************************************/
				TCCR1B =  prescaler;
	
}

//----------------------------------------------------------------------------------------------------------------
void pwm_run(void){
				/***********************************/
				uint8_t EE_value_2;
				EE_value_2 = eeprom_read_byte((uint8_t*)22); //read the value stored in the memory
				_delay_ms(20);
				switch (EE_value_2){
					case (1):
					top_value =  255;                   //15625hz
					break;
					case (2):
					top_value =  199; 	                //20000hz
					break;
					case (3):
					top_value =  180; 	                //22099hz
					break;
					case (4):
					top_value =  159; 	                //25000hz
					break;
					case (5):
					top_value =  104;	                //38095hz
					break;
					case (6):
					top_value =  89; 	               //44444hz
					break;
					case (7):
					top_value =  75; 	               //52632hz
					break;
					case (8):
					top_value =  65; 	               //60606hz
					break;
					case (9):
					top_value =  55; 	               //71429hz
					break;
					//default:
					//TCCR1B =  0x00;
				}//end of switch
				/*******************************************/
				OCR1C =  top_value;
				OCR1A =  top_value /2;
				OCR1B =  top_value /2;
	
	}
//----------------------------------------------------------------------------------------------------------------
void start_pwm(unsigned char prescaler,unsigned char F_PWM){
	
            LED_ON;
			//  F_PWM=(F_CPU/N)/(1+OCR1C)
			//  ((F_CPU/N)/F_PWM)-1  = OCR1C
			//  Duty_cycle= OCR1C / 2

			TOP_count_value = ((F_CPU /prescaler)/F_PWM)-1;
			duty_cycle = TOP_count_value/2;

			TCNT1 = 0;                  // Reset TCNT1							//PB1 <- OC1A , PB3 <- OC1B : PWM1A and PWM1B
			TCCR1A = 0b10010011; 	    //(10010011) Clear OC1A & OC1B output line on compare match, inverted line
										// not connected! (Note - COM1x1 and COM1x0 have different
										//meanings when in PWM mode) Enable PWM1A & PWM1B
										
			//PLLCSR = 0b00000111;      //(00000111) Use the PCK clock as a source 64Mhz
			
            OCR1C = TOP_count_value;    // top count value can be 0xC7 ,0xFF, 199 or 240(CK/prescaler/f (internal oscillator.4,000,000Hz))
										// Initial the Output Compare register A & B
			OCR1A = duty_cycle;         // upper value (if OCR1C = 240 then  OCR1A=120 --> 50% pulse-pause ratio)Initially 0% PWM
			OCR1B = duty_cycle;               // always 0 at the bottom
			
			TCCR1B =  prescaler; 	    //(00000101) (Clock source/Prescaler) Timer for PWM & Start Timer
}

//----------------------------------------------------------------------------------------------------------------
void stop_pwm(void){
	
	        outpout_PORT = 0x00;
			TCCR1A = 0x00;          // stop the timer
			TCCR1B = 0x00;
			OCR1A  = 0x00;
			OCR1B  = 0x00;
			OCR1C  = 0x00;
			TCNT1 = 0;
}
//----------------------------------------------------------------------------------------------------------------
void delay(unsigned char duration){//about 0.5s if delay=30 500ms
	uint8_t i;
	uint8_t j;
	
	for(i=0;i<duration;i++){
		for(j=0;j<250;j++){
			asm("NOP");
		}
	}
}
//----------------------------------------------------------------------------------------------------------------
// FUNCTION FOR SOFTWARE DELAY OF 1 mSEC (approximate.)for 1 MHZ crystal
void delay_msec(int duration) {
	int i,j;
	for(i=0;i<duration;i++){
		for(j=0;j<100;j++){
		asm("NOP");
		asm("NOP");
		}
	  }
}
//----------------------------------------------------------------------------------------------------------------
// Takes the PWM power as a percentage of full power and determines
// the value for the comparison register.
void PWM(uint8_t duty_cycle,uint8_t select){
			uint8_t PowerValue = 0;
			if ( duty_cycle > 100)duty_cycle = 100;
			PowerValue = (255/100)* duty_cycle;
			if (select==buzzer){
				OCR1A = PowerValue;	
			   }
			if (select==light ){
				OCR1B = PowerValue;
				}
}
//----------------------------------------------------------------------------------------------------------------
void pwm_fade(void){
	
				for(duty_cycle=0; duty_cycle<255; duty_cycle++){
					OCR1A=duty_cycle;  //increase the LED light intensity
					OCR1B=duty_cycle;  //increase the LED light intensity
					_delay_ms(1);
				   }			  
			   
				for(duty_cycle=255; duty_cycle>1; duty_cycle--){
					OCR1A=duty_cycle;  //decrease the LED light intensity
					OCR1B=duty_cycle;  //decrease the LED light intensity
					_delay_ms(1);
				}			
}
//----------------------------------------------------------------------------------------------------------------
#endif /* PWM_H_ */
//--------------------------------------------------------------------------------------------
