/*
 * OCR_setting.h
 *
 * Created: 11/20/2024 23:16:43
 *  Author: User
 */ 
//--------------------------------------------------------------------------------------------
#ifndef OCR_SETTING_H_
#define OCR_SETTING_H_
//--------------------------------------------------------------------------------------------
#include <avr/io.h>
#include <util/delay.h>
//--------------------------------------------------------------------------------------------
/*
	Bit:                7 6 5 4 3 2 1 0
	TCCR1A:  COM1A1 COM1A0 COM1B1 COM1B0 FOC1A FOC1B PWM1A PWM1B
	
	Bit:                7 6 5 4 3 2 1 0
	TCCR1B : CTC1 PSR1 � � CS13 CS12 CS11 CS10 
	
	Bit:                7 6 5 4 3 2 1 0
	PLLCSR: � � � � � PCKE PLLE PLOCK 
	
	
	CS13 CS12 CS11 CS10
	0 0 0 1 CK
	0 0 1 0 CK/2
	0 0 1 1 CK/4
	0 1 0 1 CK/16
	0 1 1 1 CK/64

	*/

	/*
	target_timer_count=F_CPU/frequency + 1;
	OCR1A= (target_timer_count * 9 / 10);
	OCR1B= (target_timer_count * 5 / 10);
	play_note(D6,200);
	_delay_ms(50);
	 */
//--------------------------------------------------------------------------------------------
void setup_OCR(){
	//PB1 <- OC1A , PB3 <- OC1B : PWM1A and PWM1B 
	TCCR1A = 0x93; 	    //(10010011) Clear OC1A & OC1B output line on compare match, inverted line
	                    // not connected! (Note - COM1x1 and COM1x0 have different
	                     //meanings when in PWM mode) Enable PWM1A & PWM1B  
	
	TCCR1B = 0x05; 	//(00000101) Clock source/16 Timer for PWM & Start Timer
	PLLCSR = 0x07;  //(00000111) Use the PCK clock as a source
	OCR1A=0x00;   // upper value (e.g. a=120 -> 50% pulse-pause ratio)Initially 0% PWM
	OCR1B=0x00;   // always 0 at the bottom			
	OCR1C = 0xFF; // top count value can be 0xC7 ,0xFF, 199 or 240(CK/prescaler/f (internal oscillator.4,000,000Hz))  		
	TCNT1 = 0x00;
}
//--------------------------------------------------------------------------------------------
#endif /* OCR_SETTING_H_ */
//--------------------------------------------------------------------------------------------