/*
 * io.h
 *
 * Created: 6/1/2024 15:19:37
 *  editor: me
 */ 
//--------------------------------------------------------------------------------------------------------------
//Inputs/Outputs atmega16
//--------------------------------------------------------------------------------------------------------------
#ifndef IO_H_
#define IO_H_
//--------------------------------------------------------------------------------------------------------------
#include <avr/io.h>
//---------------------------------------------------------------------------------------------------
#define    menu_back               PA5                // input with pull-up // press the U button
#define    menu_next               PA6                // input with pull-up // press the D button
#define    sub_back                PA4                // input with pull-up // press the L button
#define    sub_next                PA7                // input with pull-up // press the R button

#define    inpout_DDR           DDRA
#define    inpout_PORT          PORTA
#define    inpout_PIN           PINA

#define    Enter_start           PA4                // input with pull-up // press the START button
#define    Exit_stop             PA5                // input with pull-up // short the NOP switch
#define    Start_Limit           PA6                // input with pull-up // short the Start Limit switch
#define    End_Limit             PA7                // input with pull-up // short the End Limit switch

#define    outpout_DDR           DDRB
#define    outpout_PORT          PORTB

#define    LED                   PB5       // LED
#define    BUZ                   PB6        // BUZZER
#define    LED_ON                outpout_PORT |= 1 << LED;
#define    LED_off               outpout_PORT &= ~(1 << LED);
#define    buzzer                OCR1A       // LED
#define    light                 OCR1B       // BUZZER
//--------------------------------------------------------------------------------------------------------------
void io_init();
//--------------------------------------------------------------------------------------------------------------
// io_init routine
void io_init(){

	inpout_DDR=0x00;       //set all pins of port A as input
	inpout_PORT=0x03;      //set all pins of port A pull-ups

	outpout_DDR =0xff;     //set all pins of port B as output
	outpout_PORT =0x00;    //set all pins of port B LOW
}
//--------------------------------------------------------------------------------------------------------------
#endif //IO_H_ 
//--------------------------------------------------------------------------------------------------------------