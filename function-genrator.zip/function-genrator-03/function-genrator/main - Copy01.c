/*
 * function-genrator.c
 *
 * Created: 11/10/2024 10:49:19
 * Author : User
 */ 
//----------------------------------------------------------------------------------------------------------------
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <util/delay.h>
#include <avr/sleep.h>
#include <avr/wdt.h>

//----------------------------------------------------------------------------------------------------------------
//Attiny25/85 , running @ 1MHZ
// Using timer 1
//
//                           +-\/-+
//  Ain0       (D  5)  PB5  1|    |8   VCC
//  Ain3       (D  3)  PB3  2|    |7   PB2  (D  2)  INT0  Ain1 <- Potmeter input
//  Ain2       (D  4)  PB4  3|    |6   PB1  (D  1)        pwm1 <- Speaker output
//                     GND  4|    |5   PB0  (D  0)        pwm0 <- Led output
//                           +----+
//----------------------------------------------------------------------------------------------------------------
//Attiny26 , running @ 1MHZ
// Using timer 1
//
//                               +-\/-+
//                         PB0  1|    |20   PA0   (ADC0)    Ain0 <- Potmeter input
//pwm1 <- Speaker output   PB1  2|    |19   PA1  
//                         PB2  3|    |18   PA2  
//pwm0 <- Led outpu        PB3  4|    |17   PA3  
//                         VCC  5|    |16   GND
//                         GND  6|    |15   AVCC  
//                         PB6  7|    |14   PA4         
//                         PB7  8|    |13   PA5         
//                         PB5  9|    |12   PA6
//                         PB3 10|    |11   PA7  
//                               +----+
//  calculate output frequency
//  clock speed / prescaler / OCR1C = frequency(Hz)
//  clock speed / prescaler / frequency = OCR1C
//  OCR1C = OCR1A
//----------------------------------------------------------------------------------------------------------------
#define    LED                    PB5        // LED
#define    BUZ                    PB6       // BUZZER
#define    LED_ON                 PORTB |= 1 << LED;
#define    LED_off                PORTB &= ~(1 << LED);
#define    BUZ_ON                 PORTB |= 1 << BUZ;
#define    BUZ_off                PORTB &= ~(1 << BUZ);

#define    pot_channel            0 //port A0(ADC0) pin 20

#define    adcDisable() (ADCSR &= ~(1<<ADEN)) // disable ADC
#define    adcEnable()  (ADCSR |=  (1<<ADEN)) // re-enable ADC
uint8_t    compareValue = 0;
uint16_t   sensor_value;

//----------------------------------------------------------------------------------------------------------------
// The Frequency
#define C6  661
#define D6  588
#define E6  524
#define F6  495
#define G6  441
#define A6  393
#define B6  350
#define C7  330
#define PAUSE 80
//----------------------------------------------------------------------------------------------------------------
void play_note(unsigned int note,unsigned int duration)
{
	// Reset the 8 bit Counter
	TCNT1 = 0;
	
    uint8_t top_counter = ( note >> 8 ) & 0x00FF;
	uint8_t low_counter = note;
	// Set the Counter TOP
	//TCNT1 = ( note >> 8 ) & 0x00FF;
	//TCNT1 = note;
	TCNT1 = top_counter + low_counter;
	// Turn on the Prescaler
	TCCR1B |= (1<<CS11);
	_delay_ms(duration);

	// Turn off the Prescaler
	TCCR1B &= ~(1<<CS11);
	_delay_ms(PAUSE);
}
//----------------------------------------------------------------------------------------------------------------
void music(void){
	unsigned char repeat,PlayStatus;
	int iCount;

	DDRB = 0xFE;                  // Set PB0 as input others as Output
	PORTB = 0x00;
	DDRA = 0x00;                  // Set PORTA as Input
	PORTA = 0xFF;
	

	// Initial PWM (using Timer/Counter2)
	//TCCR2A=0b10000011;            // Fast PWM Mode, Clear on OCRA
	//TCCR2B=0b00000100;            // Used f-CLK/64 prescaler
	//OCR2A=0;                      // Initial the OC2A (PB3) Out to 0

	// Set ADMUX Channel for Volume
	ADMUX=0x00;
	// Initial the ADC Circuit
	ADCSR = (1<<ADEN) | (1<<ADPS2) | (1<<ADPS1);
	// Free running Mode
	ADCSR = (1<<ADFR);
	// Disable digital input on ADC0
	//DIDR0 = 0x01;

	// Set the Timer/Counter Control Register
	TCCR1A = (1<<COM1A1)|(1<<COM1A0); // Set OC1A when up counting, clear when down counting.Set the OC1A output line.
	TCCR1A = (1<<PWM1A);              // Phase/Freq-correct PWM, top value = ICR1
	repeat=0;
	PlayStatus=0;                     // Initial Play Status
	//main LOOP
		if (PlayStatus) {
			// Start conversion by setting ADSC on ADCSRA Register
			ADCSR |= (1<<ADSC);
			// wait until conversion complete ADSC=0 -> Complete
			while (ADCSR & (1<<ADSC));
			// Get the 8 bit ADC Result
			OCR1A=ADC;
			

			play_note(D6,200);
			if (!repeat) {
				play_note(C6,500);
				} else {
				play_note(C6,1000);
			}

			if (!repeat) {
				
				
				play_note(D6,500);
			}

			if(repeat) {
				_delay_ms(1000);
				repeat=0;
				play_note(C7,100);
				play_note(C7,1500); // TA-DA
				_delay_ms(5000);
				PlayStatus=0; // Deactivate PlayStatus
				// Switch Off the Back-light
				for (iCount=255;iCount > 0;iCount--) {
					OCR1B=iCount;// Decrease OCR2A
					_delay_ms(3);
				}
				} else {
				repeat=1;
			}
			}  else {
			//if (bit_is_clear(PINB, PB0)) {          // if button is pressed
				//_delay_us(100);                       // Wait for debouching
				//if (bit_is_clear(PINB, PB0)) {        // if button is pressed
					PlayStatus=1;                       // Activate PlayStatus

					// Switch On the Back light
					for (iCount=0;iCount < 255;iCount++) {
						OCR1B=iCount;	                   // Increase OCR2A
						_delay_ms(3);
					}
				}
			}
			_delay_ms(50);
		}
}
//----------------------------------------------------------------------------------------------------------------
// ADC sample at specified channel, return 10-bit result
uint16_t analogRead(uint16_t channel){
	
	ADMUX |= (channel & 0b0000111);//set ADC channel : channel must be 0 to 7  (ADC0....ADC7)
	ADMUX |= (1<<REFS1);//Internal Voltage Reference (2.56 V), AREF pin (PA3) not connected in Tiny26.
	ADCSR |=(0 << ADPS2)|(1 << ADPS1)|(1 << ADPS0);// prescalar: 8 => 1MHz/8 = 128kHz
	
	ADCSR|= (1<<ADEN);//ADC Conversion enable
	ADCSR|= (1<<ADSC);//ADC Start Conversion
	while(!(ADCSR & (1<<ADIF)));// waiting for ADIF, conversion complete,Clear flag
	ADCSR|=(1<<ADIF); // clearing of ADIF, it is done by writing 1 to it
	return (ADC);// return results
}
//----------------------------------------------------------------------------------------------------------------
uint16_t Potmeter_read(uint16_t Potmeter){

	unsigned char sample;
	sensor_value = analogRead(Potmeter);//analog to digital conversion
	for(sample=0;sample<16;sample++){
		sensor_value += analogRead(Potmeter);// read ADC samples
	}
	sensor_value >>= 4;// take average of the 16 samples 'adc_val /= 16'  0b 1111 1111 >> 4 = 0b 0000 1111
	return  sensor_value;
}
//----------------------------------------------------------------------------------------------------------------
// io_init routine
void io_init(){

	DDRA &=~(1<<PA0);       //set PA0 pins of port A as input
	//PORTA=0x01;      //set ADC0 pins of port A pull-ups

	//DDRB=0xff;      //make all pins of port B as output
	//PORTB=0x00;     // all pins of port B set low
	
	DDRB|=(1<<PB5);  //set PB5 pin as output LED
	DDRB|=(1<<PB1);  //set OC1A pin as output 

}
//----------------------------------------------------------------------------------------------------------------
void setup() {
	disableWatchdog();
	adcEnable();
	compareValue = Potmeter_read(pot_channel);
	startTimer1(); //20 - 50 kHz -> OCR0A: 25 - 10
	adcDisable();
	
	LED_ON;
	_delay_ms(1000);
	LED_off;
	_delay_ms(1000);
	stopTimer1();
	enableWatchdog();
	enterSleep();
}
//----------------------------------------------------------------------------------------------------------------
void startTimer1(void) {
	TCNT1 = 0;
	TCCR1A = 0;
	TCCR1B = 0;
	
	TCCR1B |= (1 << PSR1);    // Bit 6 � PSR1: Prescaler Reset Timer/Counter1
	TCCR1B |= (1 << CTC1);    // Bit 7 � CTC1: Clear Timer/Counter on Compare Match CTC mode
	TCCR1A |= (1 << COM1A0);  //Toggle the OC1A output line.
	TCCR1B |= (1 << CS10);    //prescaler 1 table 12-5

	OCR1A = compareValue;//Led output
	OCR1B = compareValue;//Speaker output

}
//----------------------------------------------------------------------------------------------------------------
void stopTimer1(void) {
	TCNT1 = 0;
	TCCR1A = 0;
	TCCR1B = 0;
}
//----------------------------------------------------------------------------------------------------------------
void enableWatchdog(void) {
	wdt_enable(WDTO_1S); //enable watchdog
}
//----------------------------------------------------------------------------------------------------------------
void disableWatchdog(void) {
	MCUSR &= ~(1<<WDRF); // reset status flag
	wdt_disable(); //reset watchdog
}
//----------------------------------------------------------------------------------------------------------------
void enterSleep(void) {
	set_sleep_mode(SLEEP_MODE_PWR_DOWN);
	sleep_mode();
}
//----------------------------------------------------------------------------------------------------------------
/*
//called from main() with 0x7FFF as the initial value
//(should output 50% duty PWM signal)
void TMR1_init(uint16_t value)
{
	PRR &= ~(1<<PRTIM1);     //just in case, doesn't seem to affect anything
	OCR1A = value;           //Set compare value (initially 0x7FFF)
	ICR1 = 0xFFFF            //Set timer TOP value
	TCCR1A = (1<<COM1A1)|(1<<COM1A0)|(1<<WGM11);
	TCCR1B = (1<<WGM13)|(1<<WGM12);
	DDRB |= 0b00000010;            //(0x02) Configure PB1 as output
	TCCR1B |= (1<<CS11)      //divide clock io by 8
	//Timer should now be running
}

//Timer1 Phase & frequency correct
TCCR1A|= (1<<COM1A1)|(1<<COM1B1);
TCCR1B|= (1<<WGM13);
target_timer_count=F_CPU/frequency + 1;
OCR1A= (target_timer_count * 9 / 10);
OCR1B= (target_timer_count * 5 / 10);
*/
//----------------------------------------------------------------------------------------------------------------
int main(void)
{
	io_init();
	sei();
    while (1) 
    {
       setup();
    }
}

//----------------------------------------------------------------------------------------------------------------

