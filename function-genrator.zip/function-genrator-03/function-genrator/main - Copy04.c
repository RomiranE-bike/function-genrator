/*
 * function-genrator.c
 *
 * Created: 11/10/2024 10:49:19
 * Author : User
 */ 
//----------------------------------------------------------------------------------------------------------------
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <avr/pgmspace.h>
#include "io.h"
#include "pwm.h"
//----------------------------------------------------------------------------------------------------------------
//Attiny26 , running @ 4MHZ
// Using timer 0 and 1
//
//                               +-\/-+
//                         PB0  1|    |20   PA0   (ADC0)    Ain0 <- input
//pwm1A < Speaker output   PB1  2|    |19   PA1   (ADC0)    Ain0 <- input
//                         PB2  3|    |18   PA2  
//pwm1B < Led output       PB3  4|    |17   PA3  
//                         VCC  5|    |16   GND
//                         GND  6|    |15   AVCC  
//                         PB6  7|    |14   PA4         
//                         PB7  8|    |13   PA5         
//PB5< Led output          PB5  9|    |12   PA6
//                         PB3 10|    |11   PA7  
//                               +----+
//  calculate output frequency
//  clock speed / prescaler / OCR1C = frequency(Hz)
//  clock speed / prescaler / frequency = OCR1C
//  OCR1C = OCR1A
//----------------------------------------------------------------------------------------------------------------
unsigned char N_value = N_16;
unsigned char input_value = 249;
uint16_t sequence;
uint8_t  top_value;
uint8_t  count;
//----------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------
int main(void){
	
	 io_init();				                 	
	 timer0_init();
	 timer1_init();
	
	 sei(); // Globally enable interrupts
		
		while (1) {
			  
				 /***********************************/	
		
			//for(sequence=0; sequence<255; sequence++){			
					unsigned char temp1;
					temp1 = eeprom_read_byte((uint8_t*)20); //read the value stored in the memory
					switch (temp1){
						case (1):
						TCCR1B =  N_1; 	                //(00000001) (Clock source) (1<<CS10)
						break;
						case (2):
						TCCR1B =  N_2; 	                //(00000010) (Clock source/2) (1<<CS11)
						break;
						case (4):
						TCCR1B =  N_4; 	                //(00000011) (Clock source/4) (1<<CS11)|(1<<CS10)
						break;
						case (8):
						TCCR1B =  N_8; 	                //(00000100) (Clock source/8) (1<<CS12)
						break;
						case (16):
						TCCR1B =  N_16; 	            //(00000101) (Clock source/16) (1<<CS12)|(1<<CS10)
						break;
						case (32):
						TCCR1B =  N_32; 	            //(00000110) (Clock source/32) (1<<CS12)|(1<<CS11)
						break;
						case (64):
						TCCR1B =  N_64; 	            //(00000111) (Clock source/64) (1<<CS12)|(1<<CS11)|(1<<CS10)
						break;
						//default:
						//TCCR1B =  0x00;					
					    }//end of switch
					  /*******************************************/						
						unsigned char temp2;
						temp2 = eeprom_read_byte((uint8_t*)22); //read the value stored in the memory
						OCR1C = temp2;                  // Initial the Output Compare register A & B
						OCR1A = temp2 /2;               //  50% pulse-pause ratio	
						
						  //}//end of for
				
						//TCCR1B = 0x00;
						//_delay_ms(100);	
							
	
						
					}//end of while
}//end of main
//----------------------------------------------------------------------------------------------------------------
void timer1_init(void){
	TCNT1 = 0;                  // Reset TCNT1							//PB1 <- OC1A , PB3 <- OC1B : PWM1A and PWM1B
	TCCR1A = 0b10010011; 	    //(10010011) Clear OC1A & OC1B output line on compare match
	TCCR1B =  N_value; 	        //(00000101) (Clock source/Prescaler) Timer for PWM & Start Timer
	OCR1C = input_value;        // Initial the Output Compare register A & B
	OCR1A = input_value /2;     //  50% pulse-pause ratio
	OCR1B = 0;                  // always 0 at the bottom
}
//----------------------------------------------------------------------------------------------------------------
void timer0_init(void){
/*	
	Table 31. Clock 0 Prescaler Select
	CS02 CS01 CS00 Description
	0 0 0 Stop, the Timer/Counter0 is stopped
	0 0 1 CK
	0 1 0 CK/8
	0 1 1 CK/64
	1 0 0 CK/256
	1 0 1 CK/1024
	1 1 0 External Pin T0, falling edge
	1 1 1 External Pin T0, rising edge
*/	
	// T0 - for starting and operating the menu items
	
	TCNT0 = 0;   // load TCNT0
	TCCR0 = 0b00000100; //Prescaler by 256  (if 256 it means  ~122 interrupts/s)
	TIMSK   |= (1 << TOIE0); // Enable T0 overflow interrupt
	//sei();
}
//----------------------------------------------------------------------------------------------------------------
//Timer0 overflow interrupt service routine
ISR(TIMER0_OVF0_vect){
	
			//---------------------------------------------------------------------
			//if button pressed
			if((inpout_PIN &(1<<PINA0))==0){
				_delay_ms(20);
				LED_ON;
				_delay_ms(100);
				LED_off;
				if (N_value > 1 ){
					N_value = N_value / 2;
					_delay_ms(10);
					eeprom_write_byte((uint8_t*)20,N_value); //write memory
					_delay_ms(10);
				}//end of if
				else { N_value = 64;}//end of else
				while((inpout_PIN &(1<<PINA0))==0){}  //wait for button release
			}//end of if
			//---------------------------------------------------------------------
			//if button pressed
			if((inpout_PIN &(1<<PINA1))==0){
				_delay_ms(20);
				LED_ON;
				_delay_ms(100);
				LED_off;
				if (input_value > 55 ){
					input_value=input_value - 5;
					_delay_ms(10);
					eeprom_write_byte((uint8_t*)22,input_value); //write memory
					_delay_ms(10);
				}//end of if
				else { input_value = 255;}//end of else
				while((inpout_PIN &(1<<PINA1))==0){}  //wait for button release
			}//end of if
	

}
//--------------------------------------------------------------------------------------------------------

