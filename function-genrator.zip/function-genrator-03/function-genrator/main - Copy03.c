/*
 * function-genrator.c
 *
 * Created: 11/10/2024 10:49:19
 * Author : User
 */ 
//----------------------------------------------------------------------------------------------------------------
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include "io.h"
#include "pwm.h"
#include "menu.h"
//#include <avr/pgmspace.h>
//#include <avr/sleep.h>
//#include <avr/wdt.h>
//#include <stdlib.h>
//#include "beep.h"
//#include "OCR_setting.h"
//#include "song.h"
//----------------------------------------------------------------------------------------------------------------
//Attiny25/85 , running @ 1MHZ
// Using timer 1
//
//                           +-\/-+
//  Ain0       (D  5)  PB5  1|    |8   VCC
//  Ain3       (D  3)  PB3  2|    |7   PB2  (D  2)  INT0  Ain1 <- Potmeter input
//  Ain2       (D  4)  PB4  3|    |6   PB1  (D  1)        pwm1 <- Speaker output
//                     GND  4|    |5   PB0  (D  0)        pwm0 <- Led output
//                           +----+
//----------------------------------------------------------------------------------------------------------------
//Attiny26 , running @ 1MHZ
// Using timer 1
//
//                               +-\/-+
//                         PB0  1|    |20   PA0   (ADC0)    Ain0 <- Potmeter input
//pwm1A < Speaker output   PB1  2|    |19   PA1  
//                         PB2  3|    |18   PA2  
//pwm1B < Led outpu        PB3  4|    |17   PA3  
//                         VCC  5|    |16   GND
//                         GND  6|    |15   AVCC  
//                         PB6  7|    |14   PA4         
//                         PB7  8|    |13   PA5         
//                         PB5  9|    |12   PA6
//                         PB3 10|    |11   PA7  
//                               +----+
//  calculate output frequency
//  clock speed / prescaler / OCR1C = frequency(Hz)
//  clock speed / prescaler / frequency = OCR1C
//  OCR1C = OCR1A
//----------------------------------------------------------------------------------------------------------------
int main(void){
	
	io_init();
	//menu_init();//Initial menu and initial function
	//timer0_init();//initial timer0 for key readings using overflow interrupts
	
	//sei(); // Globally enable interrupts
	uint8_t N_value = eeprom_read_word((uint8_t*)20); //read the value stored in the memory
	uint8_t input_value = eeprom_read_word((uint8_t*)22); //read the value stored in the memory
	//unsigned char N_value = 64;
	//unsigned char input_value = 255;
	
	TCNT1 = 0;                  // Reset TCNT1							//PB1 <- OC1A , PB3 <- OC1B : PWM1A and PWM1B
	TCCR1A = 0b10010011; 	    //(10010011) Clear OC1A & OC1B output line on compare match
	TCCR1B =  N_value; 	            //(00000101) (Clock source/Prescaler) Timer for PWM & Start Timer
	OCR1C = input_value;                  // Initial the Output Compare register A & B
	OCR1A = input_value /2;               //  50% pulse-pause ratio
	OCR1B = 0;                  // always 0 at the bottom
		
		while (1) {
			
			//set flag to 1
			//when button menu changes flag sets to 0
			//Flag=1;
			//execute function that is pointed by FPtr
			//FPtr();
	/*
			if ((inpout_PIN &(1<<PINA0))==0){
				start_pwm(N_1,f_38k);
				delay_msec(300);
				stop_pwm();
			    }
			
			if ((inpout_PIN &(1<<PINA1))==0){
				start_pwm(N_1,f_44k);
				delay_msec(300);
				stop_pwm();
			   }
			   
		*/	
	
	            
				 /***********************************/
				 //if button pressed
				 if((inpout_PIN &(1<<PINA0))==0){
					 _delay_ms(20);
					 LED_ON;
					 _delay_ms(100);
					 LED_off;
					 if (N_value > 1 ){
						 N_value = N_value / 2;
						 _delay_ms(10);
						 eeprom_write_word((uint8_t*)20,N_value); //write memory
						 _delay_ms(10);
					     }
					 else { N_value = 64;}
					 while((inpout_PIN &(1<<PINA0))==0){}  //wait for button release
				    }
					
					unsigned char temp1;
				 	temp1 = eeprom_read_word((uint8_t*)20); //read the value stored in the memory			 				   
			  		switch (temp1){
				  		  case (1):
				  		  TCCR1B =  N_1; 	            //(00000101) (Clock source/Prescaler) Timer for PWM & Start Timer
				   		  break;
						  case (2):
						  TCCR1B =  N_2; 	            //(00000101) (Clock source/Prescaler) Timer for PWM & Start Timer
			 			  break;
						  case (4):
						  TCCR1B =  N_4; 	            //(00000101) (Clock source/Prescaler) Timer for PWM & Start Timer
						  break;
						  case (8):
						  TCCR1B =  N_8; 	            //(00000101) (Clock source/Prescaler) Timer for PWM & Start Timer
						  break;
						  case (16):
						  TCCR1B =  N_16; 	            //(00000101) (Clock source/Prescaler) Timer for PWM & Start Timer
						  break;
						  case (32):
						  TCCR1B =  N_32; 	            //(00000101) (Clock source/Prescaler) Timer for PWM & Start Timer
						  break;
						  case (64):
						  TCCR1B =  N_32; 	            //(00000101) (Clock source/Prescaler) Timer for PWM & Start Timer
						  break;
					  
					  }
					  /*******************************************/
					  //if button pressed
					  if((inpout_PIN &(1<<PINA1))==0){
						  _delay_ms(20);
						  LED_ON;
						  _delay_ms(100);
						  LED_off;
						  if (input_value > 55 ){
							  input_value=input_value - 5;
							  _delay_ms(10);
							 eeprom_write_word((uint8_t*)22,input_value); //write memory
							 _delay_ms(10);  
						  }
						  else { input_value = 255;}
						  while((inpout_PIN &(1<<PINA1))==0){}  //wait for button release
					  }
					  
					  unsigned char temp2;
					  temp2 = eeprom_read_word((uint8_t*)22); //read the value stored in the memory
					  OCR1C = temp2;                  // Initial the Output Compare register A & B
					  OCR1A = temp2 /2;               //  50% pulse-pause ratio
		}
}
//----------------------------------------------------------------------------------------------------------------


    

	
	
	

