/*
 * menu.h
 *
 * Created: 11/25/2024 22:37:52
 *  Author: User
 */ 
//--------------------------------------------------------------------------------------------------------

#ifndef MENU_H_
#define MENU_H_
//--------------------------------------------------------------------------------------------------------
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <util/delay.h>
#include "io.h"
#include "pwm.h"
//--------------------------------------------------------------------------------------------------------
//flag required for exiting from functions loops
uint8_t Flag=1; //initial by io.h
//Function prototypes
//Initial menu
void menu_init(void);
//Functions for each menu item
void stop_pwm(void);//functions for sub menus of menu 1
void pwm_1k(void);//functions for sub menus of menu 2
void pwm_22k(void);
void pwm_25k(void);
void pwm_38k(void);
void pwm_44k(void);
void pwm_52k(void);
void pwm_60k(void);
void pwm_72k(void);
//--------------------------------------------------------------------------------------------------------
//SubMenu and Function table pointer update
uint8_t MFIndex(uint8_t, uint8_t);
//--------------------------------------------------------------------------------------------------------
typedef void (*FuncPtr)(void);
//function pointer
FuncPtr FPtr;
//--------------------------------------------------------------------------------------------------------
//Structure describes current menu and sub menu state
struct Menu_State{
	uint8_t menuNo;//1,2,3,...
	uint8_t subMenuNo;//1,2,3,...
}MN;
//--------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------
//Menu Strings in flash
//menu 1
const uint8_t PWM_off[]    PROGMEM="PWM_off";
const uint8_t pwm_off[]    PROGMEM="pwm_off";
//menu 2
const uint8_t PWM_on[]     PROGMEM="PWM_ON";
//Sub menus of menu 2
const uint8_t pwm_1[]      PROGMEM="1k";
const uint8_t pwm_22[]     PROGMEM="22k";
const uint8_t pwm_25[]     PROGMEM="25k";
const uint8_t pwm_38[]     PROGMEM="38k";
const uint8_t pwm_44[]     PROGMEM="44k";
const uint8_t pwm_52[]     PROGMEM="52k";
const uint8_t pwm_60[]     PROGMEM="60k";
const uint8_t pwm_72[]     PROGMEM="72k";

//more menus and sub menus can be added.
//--------------------------------------------------------------------------------------------------------
//Arrays of pointers to menu strings stored in flash
const uint8_t *MENU[] ={
	PWM_off,//menu 1 string
	PWM_on	//menu 2 string
};
//--------------------------------------------------------------------------------------------------------
const uint8_t *SUBMENU[] ={
	pwm_off,//sub menus of menu 1
	pwm_1,pwm_22,pwm_25,pwm_38,pwm_44,pwm_52,pwm_60,pwm_72//sub menus of menu 2
};
//--------------------------------------------------------------------------------------------------------
//Menu structure
//[0] -Number of first level  menu items
//[1]...[n] number of second level menu items
//EG. MSTR2[1] shows that menu item 1 has 3 sub menus
const uint8_t MSTR2[] PROGMEM ={
	
	2,	//number of menu items
	1,	//Number of sub menu items of menu item 1
	8	//Number of sub menu items of menu ite2
};
//--------------------------------------------------------------------------------------------------------
//Array of function pointers in Flash
const FuncPtr FuncPtrTable[] PROGMEM={
	stop_pwm,//functions for sub menus of menu 1	 	
	pwm_1k,pwm_22k,pwm_25k,pwm_38k,pwm_44k,pwm_52k,pwm_60k,pwm_72k//functions for sub menus of menu 1
};
//--------------------------------------------------------------------------------------------------------
void menu_init(void){
	MN.menuNo=1;
	MN.subMenuNo=1;
	FPtr=(FuncPtr)pgm_read_word(&FuncPtrTable[0]);
}
//--------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------
void timer0_init(void){
/*	
	Table 31. Clock 0 Prescaler Select
	CS02 CS01 CS00 Description
	0 0 0 Stop, the Timer/Counter0 is stopped
	0 0 1 CK
	0 1 0 CK/8
	0 1 1 CK/64
	1 0 0 CK/256
	1 0 1 CK/1024
	1 1 0 External Pin T0, falling edge
	1 1 1 External Pin T0, rising edge
*/	
	// T0 - for starting and operating the menu items
	
	TCNT0 = 0;   // load TCNT0
	TCCR0 = 0b00000101; //Prescaler by 256  (if 256 it means  ~122 interrupts/s)
	TIMSK   |= (1 << TOIE0); // Enable T0 overflow interrupt
	sei();
}
//----------------------------------------------------------------------------------------------------------------
//Timer0 overflow interrupt service routine
ISR(TIMER0_OVF0_vect){
	
	//---------------------------------------------------------------------
	//if button menu_next pressed
	if ((inpout_PIN &(1<<PINA0))==0){
		//_delay_ms(20);
		//beep();
		LED_ON;
		_delay_ms(100);
		LED_off;		
		if (MN.menuNo < pgm_read_byte(&MSTR2[0])){
			MN.menuNo++;
			MN.subMenuNo=1;
		}
		else{
			MN.menuNo=1;
		}
		
		//Clear();
		//Display menu item
		//print_menu(MENU[MN.menuNo-1],1,1);
		//Display sub menu item
		//print_menu(SUBMENU[MFIndex(MN.menuNo, MN.subMenuNo)],2,1);
		//Assign function to function pointer
		FPtr=(FuncPtr)pgm_read_word(&FuncPtrTable[MFIndex(MN.menuNo, MN.subMenuNo)]);
		//set Flag to 0 means menu have changed
		Flag=0;
		//wait for button release
		while((inpout_PIN &(1<<PINA0))==0){}		
		
	}
	//---------------------------------------------------------------------
	//If Button sub_next pressed
	if ((inpout_PIN &(1<<PINA1))==0){
		//_delay_ms(20);
		//beep();
		LED_ON;
		_delay_ms(100);
		LED_off;
		if (MN.subMenuNo<pgm_read_byte(&MSTR2[MN.menuNo])){
			MN.subMenuNo++;
		    }
		else{
			MN.subMenuNo=1;
		    }
		//Clear();
		//print_menu(MENU[MN.menuNo-1],1,1);
		//print_menu(SUBMENU[MFIndex(MN.menuNo, MN.subMenuNo)],2,1);
		//Assign function to function pointer
		FPtr=(FuncPtr)pgm_read_word(&FuncPtrTable[MFIndex(MN.menuNo, MN.subMenuNo)]);
		//set Flag to 0 means menu have changed
		Flag=0;
		while((inpout_PIN &(1<<PINA1))==0){}
	     }

}
//--------------------------------------------------------------------------------------------------------
uint8_t MFIndex(uint8_t mn, uint8_t sb){
	uint8_t p=0;//points to menu in table of function pointer
	for(uint8_t i=0; i<(mn-1); i++){
		p=p+pgm_read_byte(&MSTR2[i+1]);
	}
	p=p+sb-1;
	return p;
}
//--------------------------------------------------------------------------------------------------------
void main_menu_message(void){
	//Clear();
	//print_menu("WELCOME",1,1);
	//print_menu("pwm_repller",2,1);
}
//--------------------------------------------------------------------------------------------------------
void pwm_1k(void){
	while(Flag){
		start_pwm(N_64,f_1k);
		delay_msec(50);
		stop_pwm();
	}
}
//--------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------
void pwm_22k(void){
	while(Flag){
				start_pwm(N_1,f_22k);
				delay_msec(50);
				stop_pwm();

	}
}
//--------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------
void pwm_25k(void){
	while(Flag){
				start_pwm(N_1,f_25k);
				delay_msec(50);
				stop_pwm();

	}
}
//--------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------
void pwm_38k(void){
	while(Flag){
				start_pwm(N_1,f_38k);
				delay_msec(50);
				stop_pwm();

	}
}
//--------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------
void pwm_44k(void){
	while(Flag){
				start_pwm(N_1,f_44k);
				delay_msec(50);
				stop_pwm();

	}
}
//--------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------
void pwm_52k(void){
	while(Flag){
				start_pwm(N_1,f_52k);
				delay_msec(50);
				stop_pwm();

	}
}
//--------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------
void pwm_60k(void){
	while(Flag){
				start_pwm(N_1,f_60k);
				delay_msec(50);
				stop_pwm();

	}
}
//--------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------
void pwm_72k(void){
	while(Flag){
				start_pwm(N_1,f_72k);
				delay_msec(50);
				stop_pwm();

	}
}
//--------------------------------------------------------------------------------------------------------

#endif // MENU_H_
//--------------------------------------------------------------------------------------------------------------
