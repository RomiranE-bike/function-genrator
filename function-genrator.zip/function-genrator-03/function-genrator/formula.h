/*
 * formula.h
 *
 * Created: 11/24/2024 12:47:28
 *  Author: User
 */ 

//---------------------------------------------------------------------------------------------------------------
#ifndef FORMULA_H_
#define FORMULA_H_
//---------------------------------------------------------------------------------------------------------------
/*
	Bit:                7 6 5 4 3 2 1 0
	TCCR1A:  COM1A1 COM1A0 COM1B1 COM1B0 FOC1A FOC1B PWM1A PWM1B
	
	Bit:                7 6 5 4 3 2 1 0
	TCCR1B : CTC1 PSR1 � � CS13 CS12 CS11 CS10 
	
	Bit:                7 6 5 4 3 2 1 0
	PLLCSR: � � � � � PCKE PLLE PLOCK 
	
	
	CS13 CS12 CS11 CS10 Description Asynchronous Mode Description Synchronous Mode
	0 0 0 0 Timer/Counter1 is stopped. Timer/Counter1 is stopped.
	0 0 0 1 PCK   CK
	0 0 1 0 PCK/2 CK/2
	0 0 1 1 PCK/4 CK/4
	0 1 0 0 PCK/8 CK/8
	0 1 0 1 PCK/16 CK/16
	0 1 1 0 PCK/32 CK/32
	0 1 1 1 PCK/64 CK/64
	1 0 0 0 PCK/128 CK/128
	1 0 0 1 PCK/256 CK/256
	1 0 1 0 PCK/512 CK/512
	1 0 1 1 PCK/1024 CK/1024
	1 1 0 0 PCK/2048 CK/2048
	1 1 0 1 PCK/4096 CK/4096
	1 1 1 0 PCK/8192 CK/8192
	1 1 1 1 PCK/16384 CK/16384

	*/
//---------------------------------------------------------------------------------------------------------------
//  clock speed / prescaler / OCR1C = frequency(Hz)
//  clock speed / prescaler / frequency = OCR1C
/*
F_CPU = 4Mhz
F_PWM = F_CPU /(Prescaler * 256)   
F_PWM = F_TCK1/(OCR1C + 1)  (tiny26 data sheet page 76)
TOP_value =  F_CPU / ((2*Prescaler) * F_NOTE)
Prescaler =  F_CPU / (TOP_value * 2 * F_NOTE)
F_NOTE    =  F_CPU / (TOP_value * 2 * Prescaler)
Duty_cycle= TOP_value / 2

//---------------------------------------------------------------------------------------------------------------
 All calculations below are prepared for ATtiny13 default clock source (1.2MHz)
 F = F_CPU / (2 * N * (1 + OCRnx)), where:
 - F is a calculated PWM frequency
 - F_CPU is a clock source (1.2MHz)
 - the N variable represents the prescaler factor (1, 8, 64, 256, or 1024).
//---------------------------------------------------------------------------------------------------------------

target_timer_count=F_CPU/frequency + 1;
OCR1A= (target_timer_count * 9 / 10);
OCR1B= (target_timer_count * 5 / 10);
//---------------------------------------------------------------------------------------------------------------
PWM Frequency = Freq Clock / (prescaler x 523)//Fast and Phase Correct PWM 8 Bit
PWM Frequency = Freq Clock / (prescaler x 510)//Phase Correct PWM 8 Bit
PWM Frequency = Freq Clock / (prescaler x 256)//Fast PWM 8 Bit
Fast PWM Frequency = fclk / (N * 256), Where N is the Prescaler
Initial TIMER0 Fast PWM
Fast PWM Frequency = fclk / (N * 256), Where N is the Prescaler
f_PWM = 4000000 / (64 * 256) = 244.14 Hz
Fast PWM 8 Bit, Clear OCA0/OCB0 on Compare Match, Set on TOP
Used 64 Prescaler
Reset TCNT0
Initial the Output Compare register A & B
//---------------------------------------------------------------------------------------------------------------
Calculate the Top Value
TOP = Board Clock Frequency / (2 x N x Notes Frequency)
Where N is Prescaler: 8
TOP_value = (F_CPU / (16 * note_frequency));
//---------------------------------------------------------------------------------------------------------------
Set the TIMER1 PWM Duty Cycle on OCR1AH and OCR1AL
Always use half of the TOP value (PWM Duty Cycle ~ 50%)
duty_cycle=top_value / 2;
//---------------------------------------------------------------------------------------------------------------
The frequency of the PWM will be Timer Clock 1 Frequency divided by (OCR1C value + 1). See
the following equation: f_PWM =f_TCK1/(OCR1C + 1)  (tiny26 data sheet page 76)
Resolution_PWM = log2(OCR1C + 1)
PCK =64mhz

     Table 37. Timer/Counter1 Clock Prescaler Select in the Asynchronous Mode
PWM Frequency (kHz)    Clock Selection    CS13..CS10      OCR1C    RESOLUTION (Bits)
	20                     PCK/16             0101         199         7.6
	30                     PCK/16             0101         132         7.1
	40                     PCK/8              0100         199         7.6
	50                     PCK/8              0100         159         7.3
	60                     PCK/8              0100         132         7.1
	70                     PCK/4              0011         228         7.8
	80                     PCK/4              0011         199         7.6
	90                     PCK/4              0011         177         7.5
	100                    PCK/4              0011         159         7.3
	110                    PCK/4              0011         144         7.2
	120                    PCK/4              0011         132         7.1
	130                    PCK/2              0010         245         7.9
	140                    PCK/2              0010         228         7.8
	150                    PCK/2              0010         212         7.7
	160                    PCK/2              0010         199         7.6
	170                    PCK/2              0010         187         7.6
	180                    PCK/2              0010         177         7.5
	190                    PCK/2              0010         167         7.4
	200                    PCK/2              0010         159         7.3
	250                    PCK                0001         255         8.0
	300                    PCK                0001         212         7.7
	350                    PCK                0001         182         7.5
	400                    PCK                0001         159         7.3
	450                    PCK                0001         141         7.1
	500                    PCK                0001         127         7.0

*/
//---------------------------------------------------------------------------------------------------------------
#endif /* FORMULA_H_ */
//---------------------------------------------------------------------------------------------------------------