/*
 * ey_iran.h
 *
 * Created: 11/23/2024 22:53:52
 *  Author: User
 */ 
//--------------------------------------------------------------------------------------------
#ifndef EY-IRAN_H_
#define EY-IRAN_H_
//--------------------------------------------------------------------------------------------
/*****************************************************
Project : IRAN_M32
Chip type               : ATmega32
AVR Core Clock frequency: 1.000000 MHz
*****************************************************/
//#include <mega32.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "io.h"
//--------------------------------------------------------------------------------------------
#define sil 0
#define sol1 1
#define sol1_ 2
#define la1 3
#define la1_ 4
#define si1 5
#define do2 6
#define do2_ 7
#define re2 8
#define re2_ 9
#define mi2 10
#define fa2 11
#define fa2_ 12
#define sol2 13
#define sol2_ 14
#define la2 15
#define la2_ 16
#define si2 17
#define do3 18
#define do3_ 19
#define re3 20
#define re3_ 21
#define d1 1
#define d2 2
#define d3 3
#define d4 4
#define d6 6
#define d7 7
#define d8 8
#define d16 16
#define d32 32
//--------------------------------------------------------------------------------------------
unsigned char note_f = 0;
volatile unsigned char duration;
//--------------------------------------------------------------------------------------------
unsigned char  notes[]={re2,d4,la2,d1,sil,d1,la2,d1,sil,d1,la2,d4,
	re2,d3,sil,d1,re2,d4,la2,d1,sil,d1,la2,d1,sil,d1,la2,d4,re2,d4,la2,d4,
	la2_,d2,do3,d2,la2,d8,re3,d2,do3,d1,sil,d1,do3,d1,sil,d1,la2_,d1,sil,d1,
	la2_,d1,sil,d1,la2,d1,sil,d1,la2,d1,sil,d1,sol2,d2,fa2,d4,sol2,d2,do3,d2,
	/*la2,d8,re2,d2,do2,d2,re2,d2,re2_,d2,fa2,d2,re2_,d2,fa2,d2,sol2,d2,la2,d2,
	do3,d2,la2_,d2,la2,d2,sol2,d2,fa2,d2,re2_,d2,re2,d2,do2,d4,sol2,d1,sil,d1,
	sol2,d1,sil,d1,sol2,d4,la2,d4,la2_,d4,la2,d2,sol2,d2,fa2,d4,sol2,d4,la2,d4,
	sol2,d2,fa2,d2,re2_,d4,fa2,d4,sol2,d4,fa2,d2,re2_,d2,re2,d8,la2_,d2,la2,d1,
	sil,d1,la2,d1,sil,d1,sol2,d1,sil,d1,sol2,d1,sil,d1,fa2,d1,sil,d1,fa2,d1,
	sil,d1,re2_,d2,la2,d2,sol2,d1,sil,d1,sol2,d1,sil,d1,fa2,d1,sil,d1,fa2,d1,
	sil,d1,re2_,d1,sil,d1,re2_,d1,sil,d1,re2,d2,fa2,d2,sil,d2,fa2,d2,sol2,d2,
	la2,d8,re2,d4,la2,d1,sil,d1,la2,d1,sil,d1,la2,d4,re2,d3,sil,d1,re2,d4,
	la2,d1,sil,d1,la2,d1,sil,d1,la2,d4,re2,d4,la2,d4,la2_,d2,do3,d2,la2,d8,
	re3,d2,do3,d1,sil,d1,do3,d1,sil,d1,la2_,d1,sil,d1,la2_,d1,sil,d1,la2,d1,
	sil,d1,la2,d1,sil,d1,sol2,d2,fa2,d4,sol2,d2,do3,d2,la2,d8,re2,d2,do2,d2,
	re2,d2,re2_,d2,fa2,d2,re2_,d2,fa2,d2,sol2,d2,la2,d2,do3,d2,la2_,d2,la2,d2,
	sol2,d2,fa2,d2,re2_,d2,re2,d2,do2,d4,sol2,d1,sil,d1,sol2,d1,sil,d1,sol2,d4,
	la2,d4,la2_,d4,la2,d2,sol2,d2,fa2,d4,sol2,d4,la2,d4,sol2,d2,fa2,d2,re2_,d4,
	fa2,d4,sol2,d4,fa2,d2,re2_,d2,re2,d8,la2_,d2,la2,d1,sil,d1,la2,d1,sil,d1,
	sol2,d1,sil,d1,sol2,d1,sil,d1,fa2,d1,sil,d1,fa2,d1,sil,d1,re2_,d2,la2,d2,
	sol2,d1,sil,d1,sol2,d1,sil,d1,fa2,d1,sil,d1,fa2,d1,sil,d1,re2_,d1,sil,d1,
	re2_,d1,sil,d1,re2,d2,re2,d4,re2_,d2,fa2,d2,re2,d6,sil,d2,re2,d8,la2,d8,
	re2,d8,la2,d7,sil,d1,la2,d6,la2_,d2,do3,d6,la2_,d2,la2,d8,sil,d8,re3,d8,
	do3,d8,la2_,d8,la2,d8,sol2,d6,fa2,d2,sol2,d6,do3,d2,la2,d8,sil,d8,re2,d8,
	la2_,d8,la2,d8,sol2,d8,fa2,d6,re2_,d2,re2,d6,re2_,d2,do2,d8,sil,d8,fa2,d8,
	re2_,d8,re2,d6,sol2,d2,fa2,d8,re2_,d6,re2,d2,do2,d6,re2_,d2,re2,d4,la1,d4,
	la1_,d4,do2,d4,re2,d4,sol1,d4,do2,d4,sol1,d4,la1_,d4,re2,d4,la1,d4,re2,d4,
	sol1,d4,re2,d4,la1,d4,re2,d4,la1_,d4,re2,d4,do2,d4,re2,d4,re3,d32,do3,d6,
	re3_,d2,re3,d6,do3,d2,la2_,d6,re3,d2,do3,d6,la2_,d2,la2,d6,do3,d2,la2_,d6,
	la2,d2,sol2,d8,sil,d8,sol1,d6,la1,d2,la1_,d6,do2,d2,re2,d6,re2_,d2,do2,d6,
	re2,d2,re2_,d6,do2,d2,re2,d6,re2_,d2,re2,d8,sil,d8,do3,d8,si2,d6,re3,d2,
	do3,d16,la2_,d6,la2,d2,sol2,d6,la2_,d2,la2,d16,do3,d8,si2,d6,re3,d2,do3,d16,
	la2_,d6,la2,d2,sol2,d6,la2_,d2,la2,d16,fa2,d6,re2_,d2,fa2,d6,sol2,d2,la2,d16,
	la2_,d6,la2,d2,sol2,d6,fa2,d2,la2,d6,sol2,d2,fa2,d6,re2_,d2,sol2,d6,fa2,d2,re2_,
	d6,fa2,d2,sol2,d16,la2,d6,sol2,d2,fa2,d6,re2_,d2,sol2,d6,fa2,d2,re2_,d6,re2,d2,fa2,
	d6,re2_,d2,sol2,d6,re2_,d2,re2,d8,sil,d8*/
	};
//--------------------------------------------------------------------------------------------
unsigned char timer1_values[]={1516,1431,1350,1275,1203,1135,1072,1011,955,901,850,803,757,715,675,637,601,567,535,505,477};
//--------------------------------------------------------------------------------------------
// Timer 0 output compare interrupt service routineA
ISR(TIMER0_OVF0_vect){
	if (duration !=0) duration--;
}
//--------------------------------------------------------------------------------------------
// Timer1 output compare A interrupt service routine
ISR(TIMER1_CMPA_vect){
	if (note_f !=0){
		if ((PORTB & 0X01)==0x01) PORTB &=0b11111110;//speaker off
		else PORTB|=0X01;//speaker on
	  }
}
//--------------------------------------------------------------------------------------------
void ey_iran(void){
	unsigned int i;
	DDRB=0b00000001;//PB0 ==> speaker 
	TCCR0=0b00000101;//1024 prescaler
	OCR1C=0xb01000000;//TOP
	TCCR1B=0b10000001;//CTC mode,No prescaling for timer1
	//(� OCIE1A OCIE1B � � TOIE1 TOIE0 �)(0b00000000) Timer/CounterInterrupt Mask Register � TIMSK
	TIMSK=0b01100110;//Timer/Counter0 and 1 Output Compare Match Interrupt and Overflow Enable
	sei();

	while((inpout_PIN &(1<<PINA0))==0){
			for(i=0;i<sizeof (notes);i+=2){
						if (notes[i]!=sil){
							cli();
							note_f=1;
							duration=notes[i+1];
							TCNT1=0;
							OCR1A=timer1_values[notes[i]-1];
							sei();
							}
			
						else{
							note_f=0;
							duration=notes[i+1];
							}
						while(duration);
					}
	      }
}
//--------------------------------------------------------------------------------------------
#endif /* EY-IRAN_H_ */
//--------------------------------------------------------------------------------------------