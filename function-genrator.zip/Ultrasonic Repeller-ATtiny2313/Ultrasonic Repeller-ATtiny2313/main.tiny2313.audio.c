/*
 * Ultrasonic Repeller_ATtiny2313.c
 * Created: 5/13/2025 18:54:46
 * Author : deepseek_ai and me
 */ 
//----------------------------------------------------------------------------------------------
/**
 * Accelerating Audio Sweep Generator - ATtiny2313
 * Features:
 * - Three frequency ranges with accelerating sweeps
 * - Dynamic speed increase during operation
 * - LED visual feedback
 * - Speaker output with DC blocking
 */

#define __AVR_ATtiny2313__
#define F_CPU 16000000UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

// Hardware Connections
#define SPEAKER      PD6    // OC1A
#define BTN_MODE     PD0
#define LED_LOW      PB0
#define LED_MID      PB1
#define LED_HIGH     PB2

// Frequency Ranges (Hz)
#define LOW_MIN      20
#define LOW_MAX      200
#define MID_MIN      200
#define MID_MAX      2000
#define HIGH_MIN     2000
#define HIGH_MAX     20000

// Mode Definitions
typedef enum {
    MODE_LOW = 0,
    MODE_MID,
    MODE_HIGH,
    MODE_COUNT
} AudioMode_t;

// Global Variables
volatile uint16_t current_freq = LOW_MIN;
volatile AudioMode_t current_mode = MODE_LOW;
volatile uint8_t sweep_timer = 0;
volatile uint8_t speed_multiplier = 1;  // Starts at 1x, increases over time
volatile uint16_t speed_counter = 0;

/* ======================
   Timer1 Compare Match ISR
   ====================== */
ISR(TIMER1_COMPA_vect) {
    static uint8_t toggle = 0;
    PORTD = (toggle ^= 1) ? PORTD | _BV(SPEAKER) : PORTD & ~_BV(SPEAKER);
}

/* ======================
   Initialize Hardware
   ====================== */
void init_hardware() {
    DDRD |= _BV(SPEAKER);
    DDRB |= _BV(LED_LOW)|_BV(LED_MID)|_BV(LED_HIGH);
    PORTD |= _BV(BTN_MODE);
    
    // Timer1 Configuration
    TCCR1A = 0;
    TCCR1B = _BV(WGM12)|_BV(CS10);
    TIMSK = _BV(OCIE1A);
    
    sei();
}

/* ======================
   Set Frequency
   ====================== */
void set_frequency(uint16_t freq) {
    OCR1A = (F_CPU / (2UL * freq)) - 1;
    current_freq = freq;
}

/* ======================
   Update LEDs
   ====================== */
void update_leds() {
    PORTB &= ~(_BV(LED_LOW)|_BV(LED_MID)|_BV(LED_HIGH));
    switch(current_mode) {
        case MODE_LOW:  PORTB |= _BV(LED_LOW); break;
        case MODE_MID:  PORTB |= _BV(LED_MID); break;
        case MODE_HIGH: PORTB |= _BV(LED_HIGH); break;
    }
}

/* ======================
   Get Accelerated Dwell Time
   ====================== */
uint8_t get_dwell_time() {
    // Base dwell times divided by speed multiplier
    switch(current_mode) {
        case MODE_LOW:  return 100 / speed_multiplier;
        case MODE_MID:  return 50 / speed_multiplier;
        case MODE_HIGH: return 20 / speed_multiplier;
        default: return 50;
    }
}

/* ======================
   MAIN LOOP with Accelerating Sweeps
   ====================== */
int main(void) {
    init_hardware();
    set_frequency(LOW_MIN);
    update_leds();

    while(1) {
        // 1. Handle mode button
        if(!(PIND & _BV(BTN_MODE))) {
            _delay_ms(50);
            if(!(PIND & _BV(BTN_MODE))) {
                current_mode = (current_mode + 1) % MODE_COUNT;
                speed_multiplier = 1; // Reset speed on mode change
                
                switch(current_mode) {
                    case MODE_LOW:  current_freq = LOW_MIN; break;
                    case MODE_MID:  current_freq = MID_MIN; break;
                    case MODE_HIGH: current_freq = HIGH_MIN; break;
                }
                
                update_leds();
                set_frequency(current_freq);
                while(!(PIND & _BV(BTN_MODE)));
            }
        }

        // 2. Frequency sweeping with acceleration
        if(sweep_timer == 0) {
            // Increase speed every 100 cycles (adjust for desired acceleration)
            if(++speed_counter >= 100) {
                speed_counter = 0;
                if(speed_multiplier < 10) speed_multiplier++;
            }

            // Frequency stepping (step size also increases with speed)
            uint16_t step;
            switch(current_mode) {
                case MODE_LOW:
                    step = 5 * speed_multiplier;
                    current_freq += step;
                    if(current_freq > LOW_MAX) current_freq = LOW_MIN;
                    break;
                    
                case MODE_MID:
                    step = 20 * speed_multiplier;
                    current_freq += step;
                    if(current_freq > MID_MAX) current_freq = MID_MIN;
                    break;
                    
                case MODE_HIGH:
                    step = 100 * speed_multiplier;
                    current_freq += step;
                    if(current_freq > HIGH_MAX) current_freq = HIGH_MIN;
                    break;
            }

            set_frequency(current_freq);
            sweep_timer = get_dwell_time();
        }

        // 3. System maintenance
        _delay_ms(1);
        if(sweep_timer > 0) sweep_timer--;
    }
}