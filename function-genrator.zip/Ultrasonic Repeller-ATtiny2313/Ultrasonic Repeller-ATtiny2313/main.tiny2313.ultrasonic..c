/*
 * Ultrasonic Repeller_ATtiny2313.c
 * Created: 5/13/2025 18:54:46
 * Author : deepseek_ai and me
 */ 
//----------------------------------------------------------------------------------------------
/**
 * Ultrasonic Animal_Repeller System
 * ATtiny2313 Implementation @16MHz
 * 
 * Features:
 * - Three target modes (Dog/Cat/Insect)
 * - Dedicated indicator LEDs for each mode
 * - Optimized frequency sweeping patterns
 * - Complementary PWM for H-bridge drive
 * - Button-controlled mode selection
 * - Automatic mode cycling
 * 
 * Hardware Connections:
 * PB0 - Red LED (Dog mode indicator)
 * PB1 - Green LED (Cat mode indicator)
 * PB2 - Blue LED (Insect mode indicator)
 * PB6 - Mode selection button (active low)
 * PD6 - PWM Output A (MOSFET Gate 1)
 * PD5 - PWM Output B (MOSFET Gate 2)
 */
//----------------------------------------------------------------------------------------------
#define F_CPU 16000000UL  // Define CPU frequency for delay functions

#include <avr/io.h>       // AVR I/O definitions
#include <avr/interrupt.h> // Interrupt handling
#include <util/delay.h>    // Delay functions
#include <stdlib.h>        // For random number generation
//----------------------------------------------------------------------------------------------
/* ============================
   Animal Mode Definitions
   ============================ */
#define MODE_DOG     0     // Operating mode for dogs
#define MODE_CAT     1     // Operating mode for cats
#define MODE_INSECT  2     // Operating mode for insects
#define    button_DDR           DDRD
#define    button_PORT          PORTD
#define    buttont_PIN           PIND

#define    LEDs_DDR          DDRB
#define    LEDs_PORT         PORTB

#define    RedLED                   PB0       // Red LED (Dog mode indicator)
#define    GreenLED                 PB1          // Green LED (Cat mode indicator)
#define    BlueLED                  PB2          // Blue LED (Insect mode indicator)

/* ============================
   Frequency Range Constants
   (Scientifically-tested effective ranges)
   ============================ */
#define DOG_MIN     23000  // 23kHz - Start of dog repelling range
#define DOG_MAX     27000  // 27kHz - End of dog range
#define CAT_MIN     30000  // 30kHz - Start of cat repelling range
#define CAT_MAX     38000  // 38kHz - End of cat range
#define INSECT_MIN  35000  // 35kHz - Start of insect repelling range
#define INSECT_MAX  50000  // 50kHz - End of insect range

/* ============================
   Timing Parameters
   ============================ */
#define DOG_DWELL     30    // Time (ms) at each frequency - Dog mode
#define CAT_DWELL     50    // Time (ms) at each frequency - Cat mode
#define INSECT_DWELL  20    // Time (ms) at each frequency - Insect mode
#define MODE_DURATION 30000 // Time (ms) before auto mode switch
//----------------------------------------------------------------------------------------------
/* ============================
   Global Variables
   ============================ */
volatile uint16_t current_freq;     // Current output frequency (Hz)
volatile uint8_t current_mode = MODE_DOG; // Current operating mode
volatile uint32_t system_timer = 0; // Counts down mode duration (ms)
volatile uint16_t sweep_timer = 0;  // Counts down dwell time at each frequency
//----------------------------------------------------------------------------------------------
/* ============================
   Timer1 Compare Match ISR
   Description: Generates complementary PWM signals for H-bridge
   Trigger: Timer1 compare match (OCR1A)
   Frequency: Twice the set ultrasonic frequency
   ============================ */
ISR(TIMER1_COMPA_vect) {
    static uint8_t pwm_toggle = 0; // Tracks PWM state
    
    if(pwm_toggle) {
        PORTD |= (1<<PB6);   // Set PWM A (MOSFET1 on)
        PORTD &= ~(1<<PB5);  // Clear PWM B (MOSFET2 off)
    } else {
        PORTD &= ~(1<<PB6);  // Clear PWM A (MOSFET1 off)
        PORTD |= (1<<PB5);   // Set PWM B (MOSFET2 on)
    }
    pwm_toggle ^= 1; // Toggle state for next interrupt
}
//----------------------------------------------------------------------------------------------
/* ============================
   Timer0 Overflow ISR
   Description: Handles system timing and LED control
   Trigger: Timer0 overflow (1ms interval)
   ============================ */
ISR(TIMER0_OVF_vect) {
    static uint16_t ms_count = 0; // Millisecond counter
    
    // Update 1-second counter
    if(++ms_count >= 1000) {
        ms_count = 0;
        if(system_timer > 0) system_timer--;
    }
//----------------------------------------------------------------------------------------------    
    // LED Control - Different patterns per mode
    static uint8_t led_counter = 0; // LED timing counter
    led_counter++;
 //----------------------------------------------------------------------------------------------   
    switch(current_mode) {
        case MODE_DOG:
            // Red LED pulses at 2Hz (100ms on/off)
            PORTB = (led_counter % 100 < 50) ? (1<<PB0) : 0;
            PORTB &= ~((1<<PB1)|(1<<PB2)); // Turn off other LEDs
            break;
            
        case MODE_CAT:
            // Green LED pulses at 2Hz (250ms on/off)
            PORTB = (led_counter % 80< 40) ? (1<<PB1) : 0;
            PORTB &= ~((1<<PB0)|(1<<PB2)); // Turn off other LEDs
            break;
            
        case MODE_INSECT:
            // Blue LED pulses at 2Hz (250ms on/off)
            PORTB = (led_counter % 50 < 25) ? (1<<PB2) : 0; 
            PORTB &= ~((1<<PB0)|(1<<PB1)); // Turn off other LEDs
            break;
    }
}
//----------------------------------------------------------------------------------------------
/* ============================
   set_frequency()
   Description: Configures Timer1 to generate desired frequency
   Parameters: freq - Target frequency in Hz
   ============================ */
void set_frequency(uint16_t freq) {
    uint16_t prescaler = 1;      // Start with lowest prescaler
    uint16_t top = (F_CPU / (2 * freq * prescaler)) - 1; // Calculate TOP value
    
    // Find appropriate prescaler if TOP exceeds 16-bit limit
    while(top > 65535 && prescaler < 1024) {
        prescaler <<= 3; // Next prescaler option (1,8,64,256,1024)
        top = (F_CPU / (2 * freq * prescaler)) - 1;
    }
    
    // Configure Timer1 registers
	//TCCR1A = (1<<COM1A1)|(1<<COM1A0)|(1<<COM1B1)|(1<<COM1B0);
    TCCR1A = (1<<WGM11);               // Fast PWM mode using ICR1
    TCCR1B = (1<<WGM13)|(1<<WGM12);    // Waveform generation mode
    ICR1 = top;                        // Set TOP value for frequency
    OCR1A = top/2;                     // 50% duty cycle
    
    // Set prescaler bits based on calculation
    if(prescaler == 1) TCCR1B |= (1<<CS10);
    else if(prescaler == 8) TCCR1B |= (1<<CS11);
    else if(prescaler == 64) TCCR1B |= (1<<CS11)|(1<<CS10);
    else if(prescaler == 256) TCCR1B |= (1<<CS12);
    else if(prescaler == 1024) TCCR1B |= (1<<CS12)|(1<<CS10);
    
    current_freq = freq; // Update global frequency variable
}
//----------------------------------------------------------------------------------------------
/* ============================
   init_system()
   Description: Initializes hardware peripherals and timers
   ============================ */
void init_system() {
    // I/O Configuration
    DDRB |= (1<<RedLED)|(1<<GreenLED)|(1<<BlueLED); // Set LED pins as outputs
    DDRD |= (1<<PB3)|(1<<PB4);          // Set PWM pins as outputs
	
    button_DDR  &= ~(1<<PD0);           // Set button pins as input         
    button_PORT |= (1<<PD0);            // Enable pull-up on mode button
	
    // Timer1 Configuration (PWM Generation)
    TCCR1A = 0;                         // Clear control registers
    TCCR1B = 0;
    TIMSK = (1<<OCIE1A);                // Enable compare match interrupt
    
    // Timer0 Configuration (System Timing)
    TCCR0A = 0;                         // Normal mode
    TCCR0B = (1<<CS01)|(1<<CS00);      // Clock/64 prescaler (1ms @16MHz)
    TIMSK |= (1<<TOIE0);                // Enable overflow interrupt
    
    sei(); // Enable global interrupts
    
    // Initialize first mode
    current_mode = MODE_DOG;
    system_timer = MODE_DURATION/1000;   // Convert to seconds
    set_frequency(DOG_MIN);              // Start at minimum dog frequency
}
//----------------------------------------------------------------------------------------------
/* ============================
   update_sweep()
   Description: Updates frequency based on current mode's sweep pattern
   Called: Main loop (every 1ms)
   ============================ */
static uint8_t dog_dir = 1; // Sweep direction (1=up, -1=down)

void update_sweep() {
    if(sweep_timer == 0) { // Only update when dwell time expires
        switch(current_mode) {
            case MODE_DOG:
                // Zig-zag sweep pattern (23-27kHz)
                
                current_freq += (dog_dir * 300); // 300Hz steps
                
                // Reverse direction at limits
                if(current_freq >= DOG_MAX) dog_dir = -1;
                else if(current_freq <= DOG_MIN) dog_dir = 1;
                
                sweep_timer = DOG_DWELL; // Reset dwell timer
                break;
                
            case MODE_CAT:
                // Ascending sawtooth pattern (30-38kHz)
                current_freq += 200; // 200Hz steps
                
                // Wrap around to minimum
                if(current_freq > CAT_MAX) current_freq = CAT_MIN;
                
                sweep_timer = CAT_DWELL; // Reset dwell timer
                break;
                
            case MODE_INSECT:
                // Random frequency jumps (35-50kHz)
                current_freq = INSECT_MIN + (rand() % (INSECT_MAX-INSECT_MIN));
                sweep_timer = INSECT_DWELL; // Reset dwell timer
                break;
        }
        set_frequency(current_freq); // Apply new frequency
    }
}
//----------------------------------------------------------------------------------------------
/* ============================
   Main Application Loop
   ============================ */
int main(void) {
    init_system(); // Initialize hardware
    
    while(1) {
        // Mode button handling (with debounce)
        if((buttont_PIN & (1<<PIND0))==0) { // Button pressed (active low)
            _delay_ms(50); // Debounce delay
            
            if((buttont_PIN & (1<<PIND0))==0) { // Still pressed after debounce
                // Cycle to next mode
                current_mode = (current_mode+1)%3;
                system_timer = MODE_DURATION/1000; // Reset mode timer
                
                // Set starting frequency for new mode
                switch(current_mode) {
                    case MODE_DOG: current_freq = DOG_MIN; break;
                    case MODE_CAT: current_freq = CAT_MIN; break;
                    case MODE_INSECT: current_freq = INSECT_MIN; break;
                }
                
                // Wait for button release
                while((buttont_PIN & (1<<PIND0))==0);
            }
        }
        
        // Automatic mode cycling
        if(system_timer == 0) {
            current_mode = (current_mode+1)%3;
            system_timer = MODE_DURATION/1000;
        }
        
        update_sweep(); // Update frequency if needed
        
        _delay_ms(1); // Reduce CPU usage
        if(sweep_timer > 0) sweep_timer--; // Decrement dwell timer
    }
}
//----------------------------------------------------------------------------------------------

