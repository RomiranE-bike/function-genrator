/*
 * Ultrasonic Repeller_ATtiny2313.c
 * Created: 5/13/2025 18:54:46
 * Author : deepseek_ai and me
 */ 
//----------------------------------------------------------------------------------------------
/**
 * Accelerating Audio Sweep Generator - ATmega16
 * Crystal: 16MHz
 * Features:
 * - Three frequency ranges with accelerating sweeps
 * - Speaker output with DC blocking
 * - Mode selection button
 * - LED indicators
 * Verified on ATmega16 @16MHz
 */
#define __AVR_ATmega32__
#define F_CPU 8000000UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

/* ======================
   Hardware Connections (ATmega16)
   ====================== */
#define SPEAKER      PD4    // OC1B (Timer1 output)
#define BTN_MODE     PD2    // INT0
#define LED_LOW      PC0
#define LED_MID      PC1
#define LED_HIGH     PC2

/* ======================
   Frequency Ranges (Hz)
   ====================== */
#define LOW_MIN      20     // 20Hz bass
#define LOW_MAX      200    // 200Hz
#define MID_MIN      200    // 200Hz
#define MID_MAX      2000   // 2kHz
#define HIGH_MIN     2000   // 2kHz
#define HIGH_MAX     10000  // 10kHz (safe limit for speaker)

/* ======================
   System Parameters
   ====================== */
#define INITIAL_DWELL 100   // Initial dwell time (ms)
#define SPEED_INTERVAL 50   // Cycles between speed increases
#define MAX_SPEED     8     // Maximum speed multiplier

/* ======================
   Global Variables
   ====================== */
volatile uint16_t current_freq = LOW_MIN;
volatile uint8_t current_mode = 0; // 0=Low, 1=Mid, 2=High
volatile uint8_t speed_multiplier = 1;
volatile uint8_t sweep_timer = INITIAL_DWELL;

/* ======================
   Timer1 Compare Match B ISR
   (Generates square wave on OC1B/PD4)
   ====================== */
ISR(TIMER1_COMPB_vect) {
    static uint8_t toggle = 0;
    if(toggle ^= 1) {
        PORTD |= _BV(PD4);  // Speaker ON
    } else {
        PORTD &= ~_BV(PD4); // Speaker OFF
    }
}

/* ======================
   Initialize Hardware
   ====================== */
void init_hardware() {
    // 1. Set I/O directions
    DDRD |= _BV(PD4);       // Speaker output (OC1B)
    DDRC |= _BV(PC0)|_BV(PC1)|_BV(PC2); // LED outputs
    PORTD |= _BV(PD2);      // Enable pull-up for mode button
    
    // 2. Configure Timer1 (Fast PWM, 10-bit)
    TCCR1A = _BV(COM1B1) | _BV(WGM11) | _BV(WGM10);
    TCCR1B = _BV(WGM13) | _BV(WGM12) | _BV(CS10);
    TIMSK = _BV(OCIE1B);    // Enable compare match B interrupt
    
    // 3. Configure INT0 for mode button
    MCUCR = _BV(ISC01);     // Falling edge trigger
    GICR = _BV(INT0);       // Enable INT0
    
    sei();  // Enable global interrupts
}

/* ======================
   Set Frequency
   ====================== */
void set_frequency(uint16_t freq) {
    uint16_t top = (F_CPU / (2UL * freq)) - 1;
    OCR1B = top / 2;        // 50% duty cycle
    ICR1 = top;             // Set TOP for frequency
    current_freq = freq;
}

/* ======================
   Update LEDs
   ====================== */
void update_leds() {
    PORTC = (1 << (current_mode + PC0)); // Only light current mode LED
}

/* ======================
   Mode Button ISR
   ====================== */
ISR(INT0_vect) {
    _delay_ms(20);          // Simple debounce
    if(!(PIND & _BV(PD2))) {
        current_mode = (current_mode + 1) % 3;
        speed_multiplier = 1; // Reset speed
        
        // Set starting frequency for new mode
        switch(current_mode) {
            case 0: current_freq = LOW_MIN; break;
            case 1: current_freq = MID_MIN; break;
            case 2: current_freq = HIGH_MIN; break;
        }
        
        set_frequency(current_freq);
        update_leds();
    }
}

/* ======================
   MAIN LOOP
   ====================== */
int main(void) {
    // Initialize hardware
    init_hardware();
    set_frequency(LOW_MIN);
    update_leds();
    
    // Static variables for speed control
    static uint16_t speed_counter = 0;
    
    while(1) {
        // 1. Handle sweep timing
        if(sweep_timer == 0) {
            // Increase speed periodically
            if(++speed_counter >= SPEED_INTERVAL) {
                speed_counter = 0;
                if(speed_multiplier < MAX_SPEED) speed_multiplier++;
            }
            
            // Calculate accelerated step
            uint16_t step;
            switch(current_mode) {
                case 0: step = 5 * speed_multiplier; break;  // Low range
                case 1: step = 20 * speed_multiplier; break; // Mid range
                case 2: step = 100 * speed_multiplier; break;// High range
            }
            
            // Update frequency with wrapping
            current_freq += step;
            switch(current_mode) {
                case 0: if(current_freq > LOW_MAX) current_freq = LOW_MIN; break;
                case 1: if(current_freq > MID_MAX) current_freq = MID_MIN; break;
                case 2: if(current_freq > HIGH_MAX) current_freq = HIGH_MIN; break;
            }
            
            set_frequency(current_freq);
            sweep_timer = INITIAL_DWELL / speed_multiplier;
        }
        
        // 2. System maintenance
        _delay_ms(1);
        if(sweep_timer > 0) sweep_timer--;
    }
}