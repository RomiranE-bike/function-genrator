/*
 * function-genrator.c
 *
 * Created: 11/10/2024 10:49:19
 * Author : User
 */ 
//----------------------------------------------------------------------------------------------------------------
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <avr/pgmspace.h>
#include <stdlib.h>
#include "io.h"
#include "pwm.h"
//----------------------------------------------------------------------------------------------------------------
//chip config
/*
//Attiny26 , running @ 4MHZ
// Using timer 0 and 1
//
//                               +-\/-+
//                         PB0  1|    |20   PA0   (ADC0)    Ain0 <- input
//pwm1A < Speaker output   PB1  2|    |19   PA1   (ADC0)    Ain0 <- input
//                         PB2  3|    |18   PA2  
//pwm1B < Led output       PB3  4|    |17   PA3  
//                         VCC  5|    |16   GND
//                         GND  6|    |15   AVCC  
//                         PB6  7|    |14   PA4         
//                         PB7  8|    |13   PA5         
//PB5< Led output          PB5  9|    |12   PA6
//                         PB3 10|    |11   PA7  
//                               +----+
//  calculate output frequency
//  clock speed / prescaler / OCR1C = frequency(Hz)
//  clock speed / prescaler / frequency = OCR1C
//  OCR1C = OCR1A
*/
//----------------------------------------------------------------------------------------------------------------
uint8_t F_pwm = 0;
uint8_t timer_Clk = 0 ;
//----------------------------------------------------------------------------------------------------------------
int main(void){
	
	 io_init();				                 	
	 timer0_init();
	 timer1_init();
	
	 sei(); // Globally enable interrupts
		
		while (1) {
			      LED_off;
				  prescaler_change();
				  pwm_run();					 
					 		
					}//end of while
}//end of main
//----------------------------------------------------------------------------------------------------------------
void timer0_init(void){
/*	
	Table 31. Clock 0 Prescaler Select
	CS02 CS01 CS00 Description
	0 0 0 Stop, the Timer/Counter0 is stopped
	0 0 1 CK
	0 1 0 CK/8
	0 1 1 CK/64
	1 0 0 CK/256
	1 0 1 CK/1024
	1 1 0 External Pin T0, falling edge
	1 1 1 External Pin T0, rising edge
*/	
	// T0 - for starting and operating the menu items
	
	TCNT0 = 0;   // load TCNT0
	TCCR0 = 0b00000100; //Prescaler by 256  (if 256 it means  ~122 interrupts/s)
	TIMSK   |= (1 << TOIE0); // Enable T0 overflow interrupt
	//sei();
}
//----------------------------------------------------------------------------------------------------------------
void timer1_init(void){
	TCNT1 = 0;                  // Reset TCNT1							//PB1 <- OC1A , PB3 <- OC1B : PWM1A and PWM1B
	TCCR1A = 0b10010011; 	    //(10010011) Clear OC1A & OC1B output line on compare match
	TCCR1B =   N_1; 	        //(00000101) (Clock source/Prescaler) Timer for PWM & Start Timer
	OCR1C = top_value;        // Initial the Output Compare register A & B
	OCR1A = top_value/2;     //  50% pulse-pause ratio
	OCR1B = top_value;                  // always 0 at the bottom
}
//----------------------------------------------------------------------------------------------------------------
//Timer0 overflow interrupt service routine
ISR(TIMER0_OVF0_vect){
	
	        //---------------------------------------------------------------------
			
	        //if button pressed
	        if((inpout_PIN &(1<<PINA0))==0){
		        _delay_ms(20);
				LED_ON;
		        if (timer_Clk < 5 ){
			        timer_Clk = timer_Clk + 1;
					_delay_ms(10);
					eeprom_write_byte((uint8_t*)20,timer_Clk); //write memory
					_delay_ms(10);
		        }//end of if
		        else { timer_Clk = 1;}//end of else					
	          while((inpout_PIN &(1<<PINA0))==0){}  //wait for button release
             }//end of if
			
			//---------------------------------------------------------------------
			//if button pressed
			if((inpout_PIN &(1<<PINA1))==0){
				_delay_ms(20);
				LED_ON;
				if (F_pwm < 10 ){
					F_pwm = F_pwm + 1;
					_delay_ms(10);
					eeprom_write_byte((uint8_t*)22,F_pwm); //write memory
					_delay_ms(10);
				 }//end of if
				else { F_pwm = 1;}//end of else	
				while((inpout_PIN &(1<<PINA1))==0){}  //wait for button release
			  }//end of if
			
	    //---------------------------------------------------------------------
}
//--------------------------------------------------------------------------------------------------------

